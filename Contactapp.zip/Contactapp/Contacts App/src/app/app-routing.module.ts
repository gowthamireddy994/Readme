import { ContactsComponent } from './contacts/contacts.component';
import { SignupComponent } from './signup/signup.component';
import { SigninComponent } from './signin/signin.component';

import { NgModule, Component } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';




const routes: Routes = [
  {path:'', redirectTo:'signin',pathMatch:'full'},
  {path:'signin', component : SigninComponent},
  {path:'signup', component : SignupComponent},
  {path:'contacts', component : ContactsComponent}
 

 
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
