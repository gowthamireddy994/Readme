import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { Router } from '@angular/router';



@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {

  public signupForm!: FormGroup
  constructor(private formBuilder: FormBuilder, private _http: HttpClient, private router: Router) { }

  ngOnInit(): void {
    this.signupForm = this.formBuilder.group({
      email: [''],
      password: [''],
      secrete: ['']
    })
  }

  //make method to create user

  signUp() {
    this._http.post<any>("http://localhost:3000/signup", this.signupForm.value).subscribe(res=>{
  
      alert("Registration SucessFull ");
      this.signupForm.reset();
      this.router.navigate(['signin']);
      this.router.navigate(['contacts'])
    }, err => {
      alert("something went wrong")
    })
  }
}


